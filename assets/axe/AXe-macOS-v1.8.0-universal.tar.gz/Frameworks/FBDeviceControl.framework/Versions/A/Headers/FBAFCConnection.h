/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

#import <Foundation/Foundation.h>

#import <FBControlCore/FBFuture.h>
#import <FBDeviceControl/FBAMDefines.h>

@class FBAMDServiceConnection;
@protocol FBControlCoreLogger;

/**
 An Object wrapper for an Apple File Conduit handle.
 */
@interface FBAFCConnection : NSObject

#pragma mark Initializers

/**
 The Designated Initializer.

 @param connection the wrapped pointer value.
 @param calls the calls to use.
 @param logger the logger to use.
 @return a new FBAFConnection Instance.
 */
- (nonnull instancetype)initWithConnection:(AFCConnectionRef _Nonnull)connection calls:(AFCCalls)calls logger:(nullable id<FBControlCoreLogger>)logger;

/**
 Constructs an FBAFCConnection from a Service Connection and tears it down after.

 @param serviceConnection the connection to use.
 @param calls the calls to use.
 @param logger the logger to use.
 @param queue the queue to use.
 @return an FBAFCConnection instance.
 */
+ (nonnull FBFutureContext<FBAFCConnection *> *)afcFromServiceConnection:(nonnull FBAMDServiceConnection *)serviceConnection calls:(AFCCalls)calls logger:(nonnull id<FBControlCoreLogger>)logger queue:(nonnull dispatch_queue_t)queue;

#pragma mark Public Methods

/**
 Copies an item at the provided url into an application container.
 The source file can represent a file or a directory.

 @param hostPath the source file on the host.
 @param containerPath the file path relative to the application container.
 @param error an error out for any error that occurs.
 @return YES if successful, NO otherwise.
 */
- (BOOL)copyFromHost:(nonnull NSString *)hostPath toContainerPath:(nonnull NSString *)containerPath error:(NSError * _Nullable * _Nullable)error;

/**
 Creates a Directory.

 @param path the path to create.
 @param error an error out for any error that occurs.
 @return YES if successful, NO otherwise.
 */
- (BOOL)createDirectory:(nonnull NSString *)path error:(NSError * _Nullable * _Nullable)error;

/**
 Get the contents of a directory.

 @param path the path to locate.
 @param error an error out for any error that occurs.
 @return the contents of the directory.
 */
- (nullable NSArray<NSString *> *)contentsOfDirectory:(nonnull NSString *)path error:(NSError * _Nullable * _Nullable)error;

/**
 Get the contents of a file.

 @param path the path to read.
 @param error an error out for any error that occurs.
 @return the data for the file.
 */
- (nullable NSData *)contentsOfPath:(nonnull NSString *)path error:(NSError * _Nullable * _Nullable)error;

/**
 Removes a path.

 @param path the path to remove.
 @param recursively YES to recurse, NO otherwise.
 @param error an error out for any error that occurs.
 @return YES if successful, NO otherwise.
 */
- (BOOL)removePath:(nonnull NSString *)path recursively:(BOOL)recursively error:(NSError * _Nullable * _Nullable)error;

/**
 Renames a path.

 @param path the path to rename
 @param destination the destination path.
 @param error an error out for any error that occurs.
 @return YES if successful, NO otherwise.
 */
- (BOOL)renamePath:(nonnull NSString *)path destination:(nonnull NSString *)destination error:(NSError * _Nullable * _Nullable)error;

/**
 Close the connection.
 The connection should not be used after this.

 @param error an error out for any error that occurs.
 @return YES if successful, NO otherwise.
 */
- (BOOL)closeWithError:(NSError * _Nullable * _Nullable)error;

#pragma mark Properties

/**
 The wrapped 'Apple File Conduit'.
 */
@property (nullable, nonatomic, readonly, assign) AFCConnectionRef connection;

/**
 The Calls to use.
 */
@property (nonatomic, readonly, assign) AFCCalls calls;

/**
 The logger to use
 */
@property (nullable, nonatomic, readonly, strong) id<FBControlCoreLogger> logger;

/**
 The Default Calls.
 */
@property (class, nonatomic, readonly, assign) AFCCalls defaultCalls;

@end
